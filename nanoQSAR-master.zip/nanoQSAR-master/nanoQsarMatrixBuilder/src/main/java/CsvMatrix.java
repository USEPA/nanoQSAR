import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.logging.Logger;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.jblas.DoubleMatrix;
import org.jblas.Singular;
import org.jblas.Solve;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;


/**
 * @author Wilson Melendez
 *
 */
public class CsvMatrix
{
	private static int xcolumns;
	private static int ycolumns;
	private static int rowsSize;
	private static int numDataSets = 5;
	private static Integer[] numSetRows = new Integer[numDataSets];
	
	private static List<String[]> rows;
	private static String[] header;
	private static Integer[] jcolX; // Positional indices of X-matrix columns in CSV file. 
	private static Integer[] jcolY; // Positional indices of Y-matrix columns in CSV file.
	private static Double[] minValueX;
	private static Double[] minValueY;
	private static Double[] maxValueX;
	private static Double[] maxValueY;
	private static DoubleMatrix Xmatrix;
	private static DoubleMatrix Ymatrix;
	private static DoubleMatrix Umatrix;
	private static DoubleMatrix Tmatrix;
	private static DoubleMatrix Wmatrix;		
	private static DoubleMatrix Cmatrix;
	private static DoubleMatrix Pmatrix;
	private static DoubleMatrix Bmatrix;
	
	private static DoubleMatrix[] XmatrixSet = new DoubleMatrix[numDataSets];
	private static DoubleMatrix[] YmatrixSet = new DoubleMatrix[numDataSets];
	
	private static double ssx;
	private static double ssy;
	
	private static double EPSILON = 1.0e-6;
	private static double EPSILON_DEFLATION = 1.0e-6;
	
	/* Need this line to allow logging of error messages */
	private final static Logger lOGGER = Logger.getLogger( LoggerInfo.class.getName() );
	
	/**
	 * @param xcolumns the xcolumns to set
	 */
	public static void setXcolumns(int xcolumns) {
		CsvMatrix.xcolumns = xcolumns;
	}

	/**
	 * @param ycolumns the ycolumns to set
	 */
	public static void setYcolumns(int ycolumns) {
		CsvMatrix.ycolumns = ycolumns;
	}

	public static void setJcolX(ArrayList<Integer> list)
	{
		CsvMatrix.jcolX = new Integer[list.size()];
		CsvMatrix.jcolX = list.toArray(CsvMatrix.jcolX);
	}
	
	public static void setJcolY(ArrayList<Integer> list)
	{
		CsvMatrix.jcolY = new Integer[list.size()];
		CsvMatrix.jcolY = list.toArray(CsvMatrix.jcolY);
	}
	
	public static void setMinValueX(ArrayList<Double> list)
	{
		CsvMatrix.minValueX = new Double[list.size()];
		CsvMatrix.minValueX = list.toArray(CsvMatrix.minValueX);
	}
	
	public static void setMaxValueX(ArrayList<Double> list)
	{
		CsvMatrix.maxValueX = new Double[list.size()];
		CsvMatrix.maxValueX = list.toArray(CsvMatrix.maxValueX);
	}
	
	public static void setMinValueY(ArrayList<Double> list)
	{
		CsvMatrix.minValueY = new Double[list.size()];
		CsvMatrix.minValueY = list.toArray(CsvMatrix.minValueY);
	}
	
	public static void setMaxValueY(ArrayList<Double> list)
	{
		CsvMatrix.maxValueY = new Double[list.size()];
		CsvMatrix.maxValueY = list.toArray(CsvMatrix.maxValueY);
	}
	
	/**
	 * @return the logger
	 */
	public static Logger getLogger() {
		return lOGGER;
	}

	/**
	 * 
	 * @return
	 * @author Wilson Melendez
	 */
	public static List<String[]> getRows() {
		return rows;
	}

	/**
	 * 
	 * @param rows
	 * @author Wilson Melendez
	 */
	public static void setRows(List<String[]> rows) {
		CsvMatrix.rows = rows;
	}

	/**
	 * 
	 * @return
	 * @author Wilson Melendez
	 */
	public static String[] getHeader() {
		return header;
	}

	public static void setHeader(String[] header) {
		CsvMatrix.header = header;
	}
	
	/**
	 * @return the xmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getXmatrix() {
		return Xmatrix;
	}

	/**
	 * @return the ymatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getYmatrix() {
		return Ymatrix;
	}
	
	/**
	 * @return the xcolumns
	 * @author Wilson Melendez
	 */
	public static int getXcolumns() {
		return xcolumns;
	}

	/**
	 * @return the ycolumns
	 * @author Wilson Melendez
	 */
	public static int getYcolumns() {
		return ycolumns;
	}

	/**
	 * @return the rowsSize
	 * @author Wilson Melendez
	 */
	public static int getRowsSize() {
		return rowsSize;
	}

	/**
	 * @return the tmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getTmatrix() {
		return Tmatrix;
	}

	/**
	 * @return the wmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getWmatrix() {
		return Wmatrix;
	}

	/**
	 * @return the cmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getCmatrix() {
		return Cmatrix;
	}

	/**
	 * @return the pmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getPmatrix() {
		return Pmatrix;
	}
	
	/**
	 * 
	 * @return the umatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getUmatrix(){
		return Umatrix;
	}

	/**
	 * 
	 * @return the Bmatrix
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix getBmatrix(){
		return Bmatrix;
	}
	
	/**
	 * 
	 * @return
	 * @author Wilson Melendez
	 */
	public static double getSsy()
	{
		return ssy;
	}
	
	/**
	 * 
	 * @return
	 * @author Wilson Melendez
	 */
	public static double getSsx()
	{
		return ssx;
	}
	
	/**
	 * @author Wilson Melendez
	 * @param filename
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void readCsvFile(String filename) throws FileNotFoundException, IOException
	{
		FileReader fReader;
		try
		{
			fReader = new FileReader(filename); 
		}
		catch(FileNotFoundException ex)
		{
			lOGGER.severe("CSV file was not found.");	
			throw ex;
		}
		
		/* Create instance of CSVReader. */
		CSVReader csvInput = new CSVReader(fReader);
		
		/* Read contents of CSV file all at once and store it in array list. */
		rows = csvInput.readAll();
		
		/* Read the first row of the data and store it in string array named header. */
		header = rows.get(0);
		
		/* Remove the header line from the array list; header is row 0. */
		rows.remove(0);        
        
		/* Close connection to CSV file, but throw exception if failure to close. */
		try
		{
			csvInput.close();
			fReader.close();
		}
		catch(IOException ex)
		{
			lOGGER.severe("Attempt to close CSV reader failed.");	
			throw ex;
		}
	}
	
	/**
	 * This method determines the positional indices of the numeric 
	 * data in the CSV file.  It also sets maximum and minimum values
	 * for random generated data.
	 * @author Wilson Melendez
	 */
	public static void selectNumericColumns()
	{
		/* Create ArrayLists to store positional indices, minimum, 
		 * and maximum values of the X and Y matrices. */
		ArrayList<Integer> listX = new ArrayList<Integer>();
		ArrayList<Integer> listY = new ArrayList<Integer>();
		ArrayList<Double> listMinX = new ArrayList<Double>();
		ArrayList<Double> listMaxX = new ArrayList<Double>();
		ArrayList<Double> listMinY = new ArrayList<Double>();
		ArrayList<Double> listMaxY = new ArrayList<Double>();
		List<String> listHeader = Arrays.asList(header);
		
		/* Store indices and minimum/maximum random values of X-matrix columns */
		listX.add(listHeader.indexOf("CoatingAmount"));	
		listMinX.add(10.0);  listMaxX.add(100.0);
	    listX.add(listHeader.indexOf("Purity"));
	    listMinX.add(10.0);  listMaxX.add(100.0);
		listX.add(listHeader.indexOf("ContamAl")); 
		listMinX.add(10.0);  listMaxX.add(1500.0); 
		listX.add(listHeader.indexOf("ContamAs")); 
		listMinX.add(10.0);  listMaxX.add(1500.0); 
		listX.add(listHeader.indexOf("ContamBe"));	
		listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamCa")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamCo")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamCr")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamFe")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamK"));  
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamMg")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamNa")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamP"));  
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamPb")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamSb")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamSe"));  
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamSiO2"));
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamSn")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamTl")); 
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ContamV"));  
        listMinX.add(10.0);  listMaxX.add(1500.0); 
        listX.add(listHeader.indexOf("ParticleOuterDiamAvg")); 
        listMinX.add(100.0);  listMaxX.add(250.0);
        listX.add(listHeader.indexOf("ParticleOuterDiamLow")); 
        listMinX.add(10.0);  listMaxX.add(100.0); 
        listX.add(listHeader.indexOf("ParticleOuterDiamHigh")); 
        listMinX.add(250.0);  listMaxX.add(400.0);
        listX.add(listHeader.indexOf("ParticleInnerDiamAvg"));
        listMinX.add(50.0);  listMaxX.add(100.0);        
        listX.add(listHeader.indexOf("ParticleInnerDiamLow"));  
        listMinX.add(0.0);  listMaxX.add(50.0);  
        listX.add(listHeader.indexOf("ParticleInnerDiamHigh")); 
        listMinX.add(100.0);  listMaxX.add(150.0); 
        listX.add(listHeader.indexOf("ParticleLengthAvg"));
        listMinX.add(50.0);  listMaxX.add(100.0);       
        listX.add(listHeader.indexOf("ParticleLengthLow")); 
        listMinX.add(10.0);  listMaxX.add(50.0); 
        listX.add(listHeader.indexOf("ParticleLengthHigh")); 
        listMinX.add(100.0);  listMaxX.add(150.0); 
        listX.add(listHeader.indexOf("ParticleThicknessAvg"));
        listMinX.add(50.0);  listMaxX.add(100.0); 
        listX.add(listHeader.indexOf("ParticleThicknessLow")); 
        listMinX.add(10.0);  listMaxX.add(50.0);  
        listX.add(listHeader.indexOf("ParticleThicknessHigh")); 
        listMinX.add(100.0);  listMaxX.add(150.0);  
        listX.add(listHeader.indexOf("SurfaceAreaAvg")); 
        listMinX.add(150.0);  listMaxX.add(300.0); 
        listX.add(listHeader.indexOf("SurfaceAreaLow"));
        listMinX.add(10.0);  listMaxX.add(150.0);  
        listX.add(listHeader.indexOf("SurfaceAreaHigh")); 
        listMinX.add(300.0);  listMaxX.add(450.0);     
        listX.add(listHeader.indexOf("MC_TimeValue")); 
        listMinX.add(10.0);  listMaxX.add(240.0);   
        listX.add(listHeader.indexOf("MC_ParticleConcentration")); 
        listMinX.add(10.0);  listMaxX.add(100.0);     
        listX.add(listHeader.indexOf("MC_SerumConcentration"));   
        listMinX.add(10.0);  listMaxX.add(100.0);     
        listX.add(listHeader.indexOf("MC_AntibioticConcentration"));
        listMinX.add(10.0);  listMaxX.add(100.0);     
        listX.add(listHeader.indexOf("MC_DOMConcentration"));   
        listMinX.add(10.0);  listMaxX.add(20.0); 
        listX.add(listHeader.indexOf("MC_SalinityValue"));
        listMinX.add(10.0);  listMaxX.add(35.0);  
        listX.add(listHeader.indexOf("MC_pHAvg"));
        listMinX.add(4.0);  listMaxX.add(10.0);   
        listX.add(listHeader.indexOf("MC_pHLow"));  
        listMinX.add(0.0);  listMaxX.add(4.0); 
        listX.add(listHeader.indexOf("MC_pHHigh")); 
        listMinX.add(10.0);  listMaxX.add(14.0); 
        listX.add(listHeader.indexOf("MC_MediumTemp")); 
        listMinX.add(10.0);  listMaxX.add(40.0);
        listX.add(listHeader.indexOf("ZetaPotentialAvg"));
        listMinX.add(-30.0);  listMaxX.add(-100.0);
        listX.add(listHeader.indexOf("ZetaPotentialLow"));
        listMinX.add(-10.0);  listMaxX.add(-30.0); 
        listX.add(listHeader.indexOf("ZetaPotentialHigh")); 
        listMinX.add(-100.0);  listMaxX.add(-150.0);    
        listX.add(listHeader.indexOf("SizeDistribAvg"));
        listMinX.add(1000.0);  listMaxX.add(2000.0);     
        listX.add(listHeader.indexOf("SizeDistribLow")); 
        listMinX.add(10.0);  listMaxX.add(1000.0); 
        listX.add(listHeader.indexOf("SizeDistribHigh")); 
        listMinX.add(2000.0);  listMaxX.add(3000.0);   
        listX.add(listHeader.indexOf("SizeDistribAvg2")); 
        listMinX.add(1000.0);  listMaxX.add(2000.0);    
        listX.add(listHeader.indexOf("SizeDistribLow2")); 
        listMinX.add(10.0);  listMaxX.add(1000.0);   
        listX.add(listHeader.indexOf("SizeDistribHigh2"));
        listMinX.add(2000.0);  listMaxX.add(3000.0);   
        listX.add(listHeader.indexOf("SerumConcentration"));
        listMinX.add(10.0);  listMaxX.add(100.0); 
        listX.add(listHeader.indexOf("AntibioticConcentration"));  
        listMinX.add(10.0);  listMaxX.add(100.0);  
        listX.add(listHeader.indexOf("DOMConcentration")); 
        listMinX.add(10.0);  listMaxX.add(20.0);   
        listX.add(listHeader.indexOf("SalinityValue")); 
        listMinX.add(10.0);  listMaxX.add(35.0);     
        listX.add(listHeader.indexOf("pHAvg"));  
        listMinX.add(4.0);  listMaxX.add(10.0);   
        listX.add(listHeader.indexOf("pHLow")); 
        listMinX.add(0.0);  listMaxX.add(4.0);  
        listX.add(listHeader.indexOf("pHHigh")); 
        listMinX.add(10.0);  listMaxX.add(14.0);
        listX.add(listHeader.indexOf("MediumTemp"));
        listMinX.add(10.0);  listMaxX.add(40.0); 
        listX.add(listHeader.indexOf("TimeValue"));   
        listMinX.add(48.0);  listMaxX.add(72.0);   
        listX.add(listHeader.indexOf("ParticleConcentration")); 
        listMinX.add(10.0);  listMaxX.add(100.0); 
        listX.add(listHeader.indexOf("ParticleExposDuration"));
        listMinX.add(48.0);  listMaxX.add(72.0);     
        listX.add(listHeader.indexOf("UVADose")); 
        listMinX.add(0.0);  listMaxX.add(10.0); 
        listX.add(listHeader.indexOf("UVAExposDuration")); 
        listMinX.add(1.0);  listMaxX.add(2.0); 
        
        /* Determine number of X columns. */
        xcolumns = listX.size();
        
        /* Create arrays that will store indices, minimum, and 
         * maximum values of the X columns. */
        jcolX = new Integer[xcolumns];
        minValueX = new Double[xcolumns];
        maxValueX = new Double[xcolumns];
        jcolX = listX.toArray(jcolX);        
        minValueX = listMinX.toArray(minValueX);
        maxValueX = listMaxX.toArray(maxValueX);
        
        /* Store indices and minimum/maximum random values of Y-matrix columns */
        listY.add(listHeader.indexOf("ViabilityAvg"));        
        listMinY.add(10.0);  listMaxY.add(100.0); 
        listY.add(listHeader.indexOf("LC50"));
        listMinY.add(10.0);  listMaxY.add(100.0);
        
        /* Determine number of Y columns. */
        ycolumns = listY.size();
        
        /* Create arrays that will store indices, minimum, and 
         * maximum values of the Y columns. */
        jcolY = new Integer[ycolumns];
        minValueY = new Double[ycolumns];
        maxValueY = new Double[ycolumns];
        jcolY = listY.toArray(jcolY);        
        minValueY = listMinY.toArray(minValueY);
        maxValueY = listMaxY.toArray(maxValueY);
	}
	
	/**
	 * This method builds the X and Y matrices needed by the PLS Regression algorithm.
	 * Null values are converted to random values using the Math.randow() method.
	 * @author Wilson Melendez
	 */
	public static void buildMatrices()
	{		
		boolean foundNulls = false;
		rowsSize = rows.size();  // Number of rows in array list.
		Xmatrix = new DoubleMatrix(rowsSize, xcolumns);   // X matrix
		Ymatrix = new DoubleMatrix(rowsSize, ycolumns);   // Y matrix
		
		/* Check whether data has any null values. */
		for (String[] str : rows)
		{
			if (Arrays.asList(str).contains("null"))
			{
				foundNulls = true;
				break;
			}
		}
		
		if (foundNulls)		
		{
			buildMatricesContainingNulls(Xmatrix, Ymatrix);  // Handle case with null values.
		}
		else
		{
			buildMatricesWithoutNulls(Xmatrix, Ymatrix);  // Handle case with no null values.
		}		
	}
	
	/**
	 * This routine builds the X and Y matrices for the case of the original data 
	 * containing null values.
	 * @author Wilson Melendez
	 */
	public static void buildMatricesContainingNulls(DoubleMatrix Xorig, DoubleMatrix Yorig)
	{
		String[] nextLine;
		           
		/* Loop over the rows of the data */
		for (int i = 0; i < Xorig.rows; i++)
		{
			nextLine = rows.get(i);	  // Get the ith row of the data
			for (int k = 0; k < Xorig.columns; k++)   // Loop over the columns
			{
				int jcol = jcolX[k];
				Xorig.put(i,k,getValue(nextLine[jcol], minValueX[k], maxValueX[k]));
			}
			
			for (int k = 0; k < Yorig.columns; k++)
			{
				int jcol = jcolY[k];
				Yorig.put(i,k,getValue(nextLine[jcol], minValueY[k], maxValueY[k]));
			}	
				
		}
	}
	
	/**
	 * This method builds the X and Y matrices for the case of data without null values.
	 * @author Wilson Melendez
	 */
	public static void buildMatricesWithoutNulls(DoubleMatrix Xorig, DoubleMatrix Yorig)
	{
		String[] nextLine;
           
		/* Loop over the rows of the data */
		for (int i = 0; i < Xorig.rows; i++)
		{
			nextLine = rows.get(i);	  // Get the ith row of the data
			for (int k = 0; k < Xorig.columns; k++)   // Loop over the columns
			{
				int jcol = jcolX[k];
				Xorig.put(i,k,Double.parseDouble(nextLine[jcol]));
			}
			
			for (int k = 0; k < Yorig.columns; k++)
			{
				int jcol = jcolY[k];
				Yorig.put(i,k,Double.parseDouble(nextLine[jcol]));
			}	
				
		}
	}
	
	/**
	 * This method converts null to random numbers and string numerical data to double.
	 * @param strValue
	 * @param minValue
	 * @param maxValue
	 * @return
	 * @author Wilson Melendez
	 */
	public static double getValue(String strValue, double minValue, double maxValue)
	{
		double value;
		
		if (strValue.equals("null"))
		{
			value = minValue + Math.random() * (maxValue - minValue);
		}
		else
		{
			value = Double.parseDouble(strValue);
		}
		
		return value;	
	}

	/**
	 * This method converts the elements of a matrix into Z-scores.
	 * A z-score (also known as standard score) indicates how many 
	 * standard deviations an element is from the mean.  It is 
	 * calculated as Z-score = (Xi - Xavg) / sigma.
	 * Xi is the ith element of a given column; Xavg is the average 
	 * of the elements in a column in the X or Y matrix; sigma is 
	 * the standard deviation of the values in a column in the X or 
	 * Y matrix. Averages and standard deviations are calculated for 
	 * each column of the X and Y matrix.
	 * @author Wilson Melendez
	 * @param A
	 * @return
	 */
	public static void normalizeMatrix(DoubleMatrix A, DoubleMatrix meanA, DoubleMatrix stdA)
	{
		DescriptiveStatistics stats = new DescriptiveStatistics();
		for (int j = 0; j < A.columns; j++)
		{
			for (int i = 0; i < A.rows; i++)
			{
				stats.addValue(A.get(i, j));
			}
			
			double mean = stats.getMean();
			double std = stats.getStandardDeviation();
			meanA.put(j, mean);
			stdA.put(j, std);
			
			for (int i = 0; i < A.rows; i++)
			{
				double zScore = (std > 0.0) ? (A.get(i, j) - mean) / std : 0.0;
				A.put(i, j, zScore);
			}
			
			stats.clear();
		}
	}
	
	/**
	 * This method converts the elements of a matrix into Z-scores.
	 * A z-score (also known as standard score) indicates how many 
	 * standard deviations an element is from the mean.  It is 
	 * calculated as Z-score = (Xi - Xavg) / sigma.
	 * Xi is the ith element of a given column; Xavg is the average 
	 * of the elements in a column in the X or Y matrix; sigma is 
	 * the standard deviation of the values in a column in the X or 
	 * Y matrix. Averages and standard deviations are calculated for 
	 * each column of the X and Y matrix.
	 * @author Wilson Melendez
	 * @param A
	 * @return
	 */
	public static void normalizeVector(DoubleMatrix A, DoubleMatrix meanA, DoubleMatrix stdA)
	{
		DescriptiveStatistics stats = new DescriptiveStatistics();
	    for (int i = 0; i < A.rows; i++)
	    {
			stats.addValue(A.get(i,0));
		}
			
		double mean = stats.getMean();
		double std = stats.getStandardDeviation();
		meanA.put(0, mean);
		stdA.put(0, std);
			
		for (int i = 0; i < A.rows; i++)
		{
			double zScore = (std > 0.0) ? (A.get(i,0) - mean) / std : 0.0;
			A.put(i, 0, zScore);
		}
			
		stats.clear();
	}
	
	/**
	 * This method calculates the sum of the squares of a matrix.
	 * The calculation is performed by squaring each element of the 
	 * matrix and adding all squared values up. 
	 * @param A
	 * @return
	 * @author Wilson Melendez
	 */
	public static double sumOfSquares(DoubleMatrix A)
	{
		double sum2 = 0.0;
		
		for (int j = 0; j < A.columns; j++)
		{
			for (int i = 0; i < A.rows; i++)
			{
				sum2 = sum2 + Math.pow(A.get(i, j), 2);
			}
		}
		
		return sum2;
	}
	
	/**
	 * This method performs the PLS regression algorithm.
	 * @param Xorig
	 * @param Yorig
	 * @return
	 * @author Wilson Melendez
	 * @throws IOException 
	 */
	public static DoubleMatrix performPLSR(DoubleMatrix Xorig, DoubleMatrix Yorig)
	{	
		Pmatrix = null;
		Umatrix = null;
		Cmatrix = null;
		Tmatrix = null;
		Wmatrix = null;
		Bmatrix = null;
		
		/* Normalize the Xmatrix by turning each element of the 
		 * matrix into Z-scores. 
		 */
		DoubleMatrix X0 = new DoubleMatrix(Xorig.rows,Xorig.columns);
		X0.copy(Xorig);
		DoubleMatrix meanX = new DoubleMatrix(Xorig.columns);
		DoubleMatrix stdX = new DoubleMatrix(Xorig.columns);
        normalizeMatrix(X0, meanX, stdX);
        
        /* Normalize the Ymatrix by turning each element of the 
		 * matrix into Z-scores.
		 */        
        DoubleMatrix Y0 = new DoubleMatrix(Yorig.rows,Yorig.columns);
        Y0.copy(Yorig);	
		DoubleMatrix meanY = new DoubleMatrix(Yorig.columns);
		DoubleMatrix stdY = new DoubleMatrix(Yorig.columns);		
	    normalizeMatrix(Y0, meanY, stdY);
        
		/* Calculate the sum of squares for Y0. */
		ssy = sumOfSquares(Y0);
		
		/* Declare a list of double values that will hold the b
		 * coefficients.  The b values are used to predict Y. 
		 */
		List<Double> bValues = new ArrayList<Double>();
				
		/* Perform the NIPALS algorithm. NIPALS is a PLS regression 
		 * algorithm. 
		 */
		performNIPALS(X0, Y0, bValues);
		
		DoubleMatrix Bpls = null;
		DoubleMatrix BplsStar = null;
		
		/* Build the B matrix. B is a diagonal matrix that enters in the 
		 * calculation of the BPLS matrix. The diagonal elements 
		 * represent the regression weights. 
		 */
		DoubleMatrix mB = new DoubleMatrix(bValues.size());
		for (int i = 0; i < mB.length; i++)
		{
			mB.put(i,bValues.get(i));
		}		
		Bmatrix = DoubleMatrix.diag(mB);
		
		/* Calculate the Moore-Penrose pseudo-inverse of the transpose 
		 * of the P matrix. */
		DoubleMatrix ptInv = Solve.pinv(Pmatrix.transpose());
		
		/* Calculate the PLS regression weights. This is also known as 
		 * the BPLS vector. 
		 */
		Bpls = ptInv.mmul(Bmatrix).mmul(Cmatrix.transpose());
        
		/* Re-introduce units into the BPLS vector. */
		BplsStar = new DoubleMatrix(Bpls.rows + 1, Bpls.columns);
		
		for (int j = 0; j < Bpls.columns; j++)
		{
			for (int i = 0; i < Bpls.rows; i++)
			{
				double bUnits = 0.0;
				if (stdX.get(i) > 0.0)
				{
					bUnits = stdY.get(j) * Bpls.get(i,j) / stdX.get(i);
				}
				BplsStar.put(i+1, j, bUnits);
			}
		}
		
		
		/* Calculate intercepts. */
		for (int j = 0; j < Bpls.columns; j++)
		{
			double sum = 0.0;
			for (int i = 0; i < Bpls.rows; i++)
			{
				sum = sum + meanX.get(i) * BplsStar.get(i+1,j);
			}
			double intercept = meanY.get(j) - sum;
			BplsStar.put(0, j, intercept);
		}
			
		return BplsStar;				
	}
	
	/**
	 * This method is used to calculate the predicted Y values.
	 * @param Xorig
	 * @param Bstar
	 * @return
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix predictResults(DoubleMatrix Xorig, DoubleMatrix Bstar)
	{
		/* Augment the Xmatrix by adding a first column of ones. */
		DoubleMatrix Ones = DoubleMatrix.ones(Xorig.rows);
		DoubleMatrix Xaugmented = DoubleMatrix.concatHorizontally(Ones, Xorig);
		
		/* Predict the Y values */
		DoubleMatrix Ypred = Xaugmented.mmul(Bstar);
		return Ypred;
	}
	
	/**
	 * This method writes BPLS* to a CSV file.
	 * @param Bstar
	 * @author Wilson Melendez
	 */
	public static void writeBplsStarToCsv(DoubleMatrix Bstar)
	{
		String[] entries = new String[Bstar.rows];
		String filename = System.getProperty("user.dir") + "\\nanoQSAR_BPLS.csv";
		
		try
		{	
			FileWriter file = new FileWriter(filename); 
					
			/* Create an instance of the CSVWriter class and specify the comma as the 
			 * default separator. Default quote character is double quote. */ 
			CSVWriter csvOutput = new CSVWriter(file,CSVWriter.DEFAULT_SEPARATOR);
					
			/* Write header line to CSV file. */
			//csvOutput.writeNext(headerLine);   
					
			for (int i = 0; i < Bstar.rows; i++)
			{
				entries[i] = String.valueOf(Bstar.get(i));
			}
						
			/* Write row of data to output using the writeNext method. */
			csvOutput.writeNext(entries);   
			
			/* Close the writer. */
			   csvOutput.close();   
		}
		catch(IOException ex)
		{
			lOGGER.severe("FileWriter for " + filename + " could not be constructed." + ex);	
		}
	}
	
	/**
	 * This  method calculates the rank of a matrix using the results
	 * of singular value decomposition.
	 * @param A
	 * @param svdOfA
	 * @return
	 * @author Wilson Melendez
	 */
	public static double rank(DoubleMatrix A, DoubleMatrix svdOfA)
	{
		double maxSizeA = Math.max(A.rows, A.columns);
		double eps = Math.pow(2.0, -52.0);
		double maxS = svdOfA.max();
		double tol = maxSizeA * eps * maxS;
		double r = svdOfA.gt(tol).sum();
		return r;
	}
	
	/**
	 * This method performs a version of the PLSR algorithm known as
	 * NIPALS.
	 * @author Wilson Melendez
	 */
	public static void performNIPALS(DoubleMatrix X0, DoubleMatrix Y0, List<Double> bValues)
	{
		int rowsMatrix = X0.rows;
		int colsMatrix = X0.columns;
		DoubleMatrix X = new DoubleMatrix();
		DoubleMatrix Y = new DoubleMatrix();
		DoubleMatrix u = new DoubleMatrix(rowsMatrix);
		DoubleMatrix u0 = new DoubleMatrix(rowsMatrix);
		DoubleMatrix u1 = new DoubleMatrix(rowsMatrix);
		DoubleMatrix udiff = new DoubleMatrix(rowsMatrix);
		DoubleMatrix w = new DoubleMatrix(colsMatrix);		
		DoubleMatrix t = new DoubleMatrix(rowsMatrix);
		DoubleMatrix t1 = new DoubleMatrix(rowsMatrix);		
		DoubleMatrix c;		
		DoubleMatrix Xtu;
		DoubleMatrix Xw;
		DoubleMatrix Ytt;
		DoubleMatrix tdiff;
		DoubleMatrix p;		
		DoubleMatrix tpt, tct;	
		
		boolean IsFirstDeflation;
		double normX, normY0, normY1, deltaU, deltaY;
		int numDeflations = 0;
		X = X0;
		Y = Y0;
		
		/* Calculate the rank of X */
		DoubleMatrix[] fullSVD = Singular.fullSVD(X0);
		DoubleMatrix singularValuesDM = fullSVD[1];
		double rank = rank(X0, singularValuesDM);
		
		/* Set the maximum number of latent variables/structures 
		 * to the rank of the X matrix.
		 */
		int maxNumLS = (int) rank;
		
		/* Initialize parameters */
		IsFirstDeflation = true;
		normY0 = Y.norm2();
		
		do
		{		
			/* Initialize u with one of the Y columns. */
			u0 = Y.getColumn(0);
						
			numDeflations = numDeflations + 1;
			if (numDeflations > maxNumLS) break; 
			
			do
			{
				/* Calculate w and normalize the result. */
				Xtu = X.transpose().mmul(u0);				
				w = Xtu.div(Xtu.norm2());
				
				/* Calculate X-scores, t, and normalize the result. */
				Xw = X.mmul(w);				
				t1 = Xw.div(Xw.norm2());
				
				/* Calculate Y-weights, c, and normalize the result. */
				Ytt = Y.transpose().mmul(t1);
				c = Ytt.div(Ytt.norm2());
				
				/* Calculate an updated set of Y-scores, u */
				u1 = Y.mmul(c);
					
				/* Calculate the change in u and check whether it is
				 * less than a small number.
				 */
				udiff = u1.sub(u0);
				deltaU = udiff.norm2();
				u0 = u1;
				
			} while (deltaU > EPSILON);
			
			u = u1;
			t = t1;
			
			double b = t.transpose().dot(u);
			bValues.add(b);
			
			/* Compute the factor loadings for X. */
			p = X.transpose().mmul(t);
			
			/* Deflate the X and Y matrices. */
			tpt = t.mmul(p.transpose());
			tct = t.mmul(c.transpose());
			X = X.sub(tpt);
			Y = Y.sub(tct.muli(b));
			
			/* Store t, u, p, c, and w in their corresponding matrices. */
			if (IsFirstDeflation)
			{
				Tmatrix = t;
				Umatrix = u;
				Pmatrix = p;
				Cmatrix = c;				
				Wmatrix = w;
				IsFirstDeflation = false;
			}
			else
			{
				Tmatrix = DoubleMatrix.concatHorizontally(Tmatrix,t);
				Umatrix = DoubleMatrix.concatHorizontally(Umatrix,u);
				Pmatrix = DoubleMatrix.concatHorizontally(Pmatrix,p);
				Cmatrix = DoubleMatrix.concatHorizontally(Cmatrix,c);
				Wmatrix = DoubleMatrix.concatHorizontally(Wmatrix,w);				
			}
			
			/* Calculate the norms of X and Y, and the change in Y. */
			normX = X.norm2();
			normY1 = Y.norm2();
			deltaY = Math.abs(normY1 - normY0);
			normY0 = normY1;
			
		} while (normX > EPSILON_DEFLATION && deltaY > EPSILON);		
	
	}
	
	/**
	 * This method splits the original data into 5 sets.  The sets will be used
	 * to cross-validate the original data using the 5-fold cross-validation method.
	 * @author Wilson Melendez
	 */
	public static void splitDataIntoSets(DoubleMatrix X0, DoubleMatrix Y0, List<Integer> list)
	{
		for (int i = 0; i < numDataSets; i++)
		{
			XmatrixSet[i] = null;
			YmatrixSet[i] = null;
		}
		
		List<List<Integer>> indicesSets = new ArrayList<List<Integer>>();
		
		int numRows = X0.rows;
		int numCols = X0.columns;
		int numYrows = Y0.rows;
		int numYcols = Y0.columns;
		
		/* Generate list of indices. */
		for (int i = 0; i < numRows; i++)
		{
			list.add(i);
		}
		
		/* Randomly shuffle the list of indices. */
		Collections.shuffle(list);
				
		/* Set the number of elements for each fold. */
		for (int i = 0; i < numDataSets; i++)
		{
			numSetRows[i] = numRows / numDataSets;
		}
		
		/* In case we have a non-zero remainder, assign one more element to some of 
		 * the groups. */
		int remainder = numRows % numDataSets;
		if (remainder > 0)
		{
			for (int i = 0; i < remainder; i++)
			{
				numSetRows[i] = numSetRows[i] + 1;
			}
		}
		
		/* Store indices in folds. */
		int jmin = 0;
		int jmax = 0;
		for (int i = 0; i < numDataSets; i++)
		{
			indicesSets.add(new ArrayList<Integer>());
			jmax = jmax + numSetRows[i];
			for (int j = jmin; j < jmax; j++)
			{
				indicesSets.get(i).add(list.get(j));
			}
			jmin = jmin + numSetRows[i];
		}
		
		/* Split the original data in 5 sets and store them in matrices. */
		for (int k = 0; k < numDataSets; k++)
		{
			XmatrixSet[k] = new DoubleMatrix(numSetRows[k], numCols);
			YmatrixSet[k] = new DoubleMatrix(numSetRows[k], numYcols);
			for (int i = 0; i < numSetRows[k]; i++)
			{
				int rowI = indicesSets.get(k).get(i);
				for (int j = 0; j < numCols; j++)
				{
					XmatrixSet[k].put(i, j, X0.get(rowI,j));					
				}
				
				for (int j = 0; j < numYcols; j++)
				{
					YmatrixSet[k].put(i, j, Y0.get(rowI,j));
				}			    												
			}
		}
	}
	
	/**
	 * This method implements the 5-fold cross-validation algorithm.
	 * @author Wilson Melendez
	 */
	public static DoubleMatrix performFiveFoldCrossValidation()
	{
		DoubleMatrix[] Yhat = new DoubleMatrix[numDataSets];
		DoubleMatrix Ytilde = new DoubleMatrix();
		
		for (int ifold = 0; ifold < numDataSets; ifold++)
		{
			/* Leave one set out and use remaining sets to build model. */
			DoubleMatrix Xtraining = null;
			DoubleMatrix Ytraining = null;
			Yhat[ifold] = null;
			Integer[] ind = new Integer[numDataSets-1];
			
			/* Store the indices of the sets that are going to be used for the model and
			 * exclude the one that is going to be predicted. */
			int j = 0;
			for (int i = 0; i < numDataSets; i++)
			{
				if (i != ifold)
				{
					ind[j] = i;	
					j++;
				}				
			}
						
			/* Build the X and Y matrices for the model. */
			Xtraining = DoubleMatrix.concatVertically(XmatrixSet[ind[0]], XmatrixSet[ind[1]]);
			Ytraining = DoubleMatrix.concatVertically(YmatrixSet[ind[0]], YmatrixSet[ind[1]]);
			for (int i = 2; i < ind.length; i++)
			{
				Xtraining = DoubleMatrix.concatVertically(Xtraining, XmatrixSet[ind[i]]);
				Ytraining = DoubleMatrix.concatVertically(Ytraining, YmatrixSet[ind[i]]);
			}
			
			/* Perform the PLS regression analysis. */
			DoubleMatrix BplsS = performPLSR(Xtraining, Ytraining);
			
			/* Predict the Y values that were left out. */
			Yhat[ifold] = predictResults(XmatrixSet[ifold], BplsS);			
			
			/* Build the predicted Y's into a single matrix. */
			if (ifold == 0) 
			{
				Ytilde.copy(Yhat[ifold]);							
			}
			else
			{
				Ytilde = DoubleMatrix.concatVertically(Ytilde, Yhat[ifold]);	
			}
		}
		
		return Ytilde;
	}
	
	/**
	 * This method prints a matrix to standard output.
	 * @param A
	 * @author Wilson Melendez
	 */
	public static void showM(DoubleMatrix A) 
	 {
		 for (int i = 0; i < A.rows; i++) 
		 {
			 for (int j = 0; j < A.columns; j++) 
			 {
				 System.out.printf("%11.6f ", A.get(i,j)); 
			 }
	         System.out.println();
		 }	         
	 }
	  
	 /**
	  * Print single-column matrix to standard output.
	  * @author Wilson Melendez
	  */
	 public static void showV(DoubleMatrix A) 
	 {
		 for (int i = 0; i < A.rows; i++) 
		 {			 
			System.out.printf("%11.6f ", Ymatrix.get(i)); 	
			System.out.println();
		 }
	 }
}
